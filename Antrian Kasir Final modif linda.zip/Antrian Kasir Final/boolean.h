#ifndef boolean_H
#define boolean_H
#define True 1
#define False 0
#define boolean unsigned char
#endif
